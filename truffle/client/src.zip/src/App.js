import React, { useState } from "react";
import { DrizzleContext } from "drizzle-react";
import Header from './Header';
import Oracle from './Oracle';
import TopUp from './TopUp';
import Earn from './Earn';
import Withdraw from './Withdraw';
//import Parameters from './Parameters';
import Admin from './Admin';
import History from './History';
import Landing from './Landing';

import "./App.css";

const formatData = (output, data, symbol) => {
  if (output === true) {
    return String(data / 1e18) + " " + (symbol);
  } else {
    return data * 1e18;
  }
}

const App = () => {
  const [readyState, setReadyState] = useState(true);
  const [balances, setBalances] = useState(null);
  const [parameters, setParameters] = useState(null);

  return (
    <DrizzleContext.Consumer>
      {drizzleContext => {
        const { drizzle, drizzleState, initialized } = drizzleContext;

        if (!initialized) {
          return "Loading...";
        }

        if (!readyState) {
          return (
            <Landing drizzle={drizzle} drizzleState={drizzleState} ready={setReadyState} />
          )
        }

        return (
          <div className="App">
            <Header drizzle={drizzle} drizzleState={drizzleState} balances={setBalances} parameters={setParameters}  />
            <History drizzle={drizzle} drizzleState={drizzleState} parameters={parameters}/>



            <Withdraw drizzle={drizzle} drizzleState={drizzleState} formatData={formatData} />
            <Admin drizzle={drizzle} drizzleState={drizzleState} />
          </div>
        );
      }}

    </DrizzleContext.Consumer>
  )
}

export default App;

//             <Oracle drizzle={drizzle} drizzleState={drizzleState} formatData={formatData} />
//             <TopUp drizzle={drizzle} drizzleState={drizzleState} formatData={formatData} />
//             <Earn drizzle={drizzle} drizzleState={drizzleState} formatData={formatData} />